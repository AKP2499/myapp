class ApiRoutes{
  static const String BASE_URL="https://hoblist.com/api/movieList";

}